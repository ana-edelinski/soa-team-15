﻿namespace ToursService.Dtos
{

    public class TourReviewSummaryDto
    {
        public long Count { get; set; }
        public double AverageRating { get; set; }
    }
}
