package main

import "followers-service/startup"

func main() { startup.Run() }
