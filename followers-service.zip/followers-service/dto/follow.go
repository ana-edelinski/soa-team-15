package dto
// trenutno bez posebnih DTO-a; rute koriste path/query parametre
